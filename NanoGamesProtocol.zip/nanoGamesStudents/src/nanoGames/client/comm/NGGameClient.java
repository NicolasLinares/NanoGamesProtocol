package nanoGames.client.comm;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import nanoGames.message.NGControlMessage;
import nanoGames.message.NGMessage;
import nanoGames.message.NGStringMessage;
import nanoGames.message.NGTokenMessage;


//This class provides the functionality required to exchange messages between the client and the game server 
public class NGGameClient {
	private Socket socket;
	protected DataOutputStream dos;
	protected DataInputStream dis;
	
	private static final int SERVER_PORT = 6969;

	public NGGameClient(String serverName) throws IOException {
		//Creation of the socket and streams
		this.socket = new Socket(serverName, SERVER_PORT);
		this.dos = new DataOutputStream(socket.getOutputStream()); 
		this.dis = new DataInputStream(socket.getInputStream());
	}
	
	//MÉTODOS DE ENVÍO DE SOLICITUD Y RECEPCIÓN DE MENSAJE
	//-------------------------------------------------------------------------------------------------------------------------
	public boolean verifyToken(long token) throws IOException {
		// Enviamos el mensaje
		NGTokenMessage message = (NGTokenMessage) NGMessage.makeTokenMessage(NGMessage.OP_SEND_TOKEN, token);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
	
		// Esperamos respuesta
		NGControlMessage response = (NGControlMessage) NGMessage.readMessageFromSocket(dis); 		
		return (response.getOpcode() == NGMessage.OP_TOKEN_OK);
	}
	
	public boolean registerNick(String nick) throws IOException {
		//SND(nick) and RCV(NICK_OK) or RCV(NICK_DUPLICATED)
		NGStringMessage message = (NGStringMessage) NGMessage.makeStringMessage(NGMessage.OP_SEND_NICK, nick);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
		
		NGControlMessage response = (NGControlMessage) NGMessage.readMessageFromSocket(dis); 
		return (response.getOpcode() == NGMessage.OP_NICK_OK);
	}

	//add additional methods for all the messages to be exchanged between client and game server
	public String requestRoomList() throws IOException {
		NGControlMessage message = (NGControlMessage) NGMessage.makeControlMessage(NGMessage.OP_REQ_ROOMLIST);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
		
		NGStringMessage response = (NGStringMessage) NGMessage.readMessageFromSocket(dis);
		return response.getText();
	}
	
	public void requestDescription(String room) throws IOException {
		NGStringMessage message = (NGStringMessage) NGMessage.makeStringMessage(NGMessage.OP_DESCRIPTION, room);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);

		NGStringMessage response = (NGStringMessage) NGMessage.readMessageFromSocket(dis); 
		System.out.println(response.getText());
	
	}
	
	public boolean requestEnterGame(String room) throws IOException {
		NGStringMessage message = (NGStringMessage) NGMessage.makeStringMessage(NGMessage.OP_ENTER_GAME, room);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
		
		NGStringMessage response = (NGStringMessage) NGMessage.readMessageFromSocket(dis); 
		System.out.println(response.getText());
		return (response.getOpcode() == NGMessage.OP_ENTER_GAME_OK);
	}
	
	
	// MÉTODOS DE ENVÍO DE MENSAJES SIN ESPERAR RESPUESTA
	//-------------------------------------------------------------------------------------------------------------------------
	public void sendExitGame() throws IOException {
		NGControlMessage message = (NGControlMessage) NGMessage.makeControlMessage(NGMessage.OP_EXIT_GAME);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
	}
	
	public void sendPlayAgain() throws IOException {
		NGControlMessage message = (NGControlMessage) NGMessage.makeControlMessage(NGMessage.OP_PLAY_AGAIN);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
	}
	
	
	public void sendAnswer(String answer) throws IOException {
		NGStringMessage message = (NGStringMessage) NGMessage.makeStringMessage(NGMessage.OP_ANSWER, answer);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
	}
	
	//To close the communication with the server
	public void sendDisconnect() throws IOException{	
		NGControlMessage message = (NGControlMessage) NGMessage.makeControlMessage(NGMessage.OP_DISCONNECT);
		String rawMessage = message.getStringMessage();
		dos.writeUTF(rawMessage);
	}
	
	// MÉTODO DE RECEPCIÓN DE MENSAJES MIENTRAS JUGAMOS
	//-------------------------------------------------------------------------------------------------------------------------
	public NGMessage checkGameMessage() throws IOException {
		NGMessage message = NGMessage.readMessageFromSocket(dis);
		return message;
	}
	
	//Used by the shell in order to check if there is data available to read 
	public boolean isDataAvailable() throws IOException {
		return (dis.available() != 0);
	}

	
	
}
