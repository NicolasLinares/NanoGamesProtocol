package nanoGames.client.application;

import java.io.IOException;

import nanoGames.broker_client.BrokerClient;
import nanoGames.client.comm.NGGameClient;
import nanoGames.client.shell.NGCommands;
import nanoGames.client.shell.NGShell;
import nanoGames.message.NGGameInfoMessage;
import nanoGames.message.NGMessage;
import nanoGames.message.NGStringMessage;

public class NGController {
	// Number of attempts to get a token
	private static final int MAX_NUMBER_OF_ATTEMPTS = 5;

	// The client for the broker
	private BrokerClient brokerClient;
	// The client for the game server
	private NGGameClient ngClient;
	// The shell for user commands from the standard input
	private NGShell shell;
	// Last command provided by the user
	private byte currentCommand;
	// Nickname of the user
	private String nickname;
	// Current room of the user (if any)
	public String room;
	private String rooms;
	// Current answer of the user (if any)
	private String answer;
	// Rules of the game
	private String rules = "";
	// Token obtained from the broker
	private long token = 0;
	// Server hosting the games
	private String serverHostname;
	
	// Para restringir el uso de comandos y seguir el esquema del autómata
	private boolean verifyNick = false; // restringe el uso del comando nick cuando ya lo hemos elegido
	private boolean verifyList = false; // restringe el uso del comando roomlist si no hemos elegido antes el nick
	private boolean verifyTurn = true; // restringe el uso del comando a <answer> si no es nuestro turno
	
	// Static porque son utilizados en la clase NGShell
	public static boolean verifyExit = false;  // restringe el uso del comando exit en mitad de una partida
	public static boolean verifyAgain = false; // restringe el uso del comando again en mitad de una partida
	
	public NGController(String brokerHostname, String serverHostname) {
		this.brokerClient = new BrokerClient(brokerHostname);
		this.shell = new NGShell();
		this.serverHostname = serverHostname;
	}

	public byte getCurrentCommand() {
		return this.currentCommand;
	}

	public void setCurrentCommand(byte command) {
		this.currentCommand = command;
	}

	// MÉTODOS DE PROCESAMIENTO DE COMANDOS:
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	public void setCurrentCommandArguments(String[] args) {
		// According to the command we register the related parameters
		// We also check if the command is valid in the current state
		switch (currentCommand) {
		case NGCommands.COM_NICK:
			nickname = args[0];
			break;
		case NGCommands.COM_ENTER:
			room = args[0];
			break;
		case NGCommands.COM_ANSWER:
			answer = args[0];
			break;
		case NGCommands.COM_DESCRIPTION:
			room = args[0];
			break;
		default:
		}
	}

	// Process commands provided by the users when they are not in a room
	public void processCommand() {
		switch (currentCommand) {
		case NGCommands.COM_TOKEN:
			getTokenAndDeliver();
			break;
		case NGCommands.COM_NICK:
			registerNickName();
			break;
		case NGCommands.COM_ROOMLIST:
			getAndShowRooms();
			break;
		case NGCommands.COM_DESCRIPTION:
			if (verifyNick && verifyList) {
				getDescriptionRoom();
			}else 
				System.out.println("* Request the roomlist first.");
			break;
		case NGCommands.COM_ENTER:
			enterTheGame();
			break;
		case NGCommands.COM_QUIT:
			if (verifyNick && verifyList) {
				disconnect();
				brokerClient.close();
			}else {
				System.out.println("Impossible disconnect, try it again later.");
				currentCommand = NGCommands.COM_INVALID; // debo asignarle otro valor pues cuando se llama a quit la primera vez
														 // entonces NanoGame termina su ejecución
			}
			break;
		default:
		}
	}

	
	// MÉTODOS UTILIZADOS FUERA DE LA ROOM
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	private void registerNickName() {
		if (!verifyNick) {
			// Intentamos registrar el nick en el servidor
			try {
				if (ngClient.registerNick(nickname)) {
					verifyNick = true;
					System.out.println("* Nick \"" +  this.nickname  + "\" accepted.");
				}else
					System.out.println("* Nick \"" +  this.nickname  + "\" in use, choose another option.");
			} catch (IOException e) {
				System.err.println("ERROR: impossible to register nick -- enterTheGame() from NGController Class.");
				e.printStackTrace();
			}
		}else 
			System.out.println("* You can only choose the nick once.");
	}
	
	private void getAndShowRooms() {
		if (verifyNick) {
				try {
					this.rooms = ngClient.requestRoomList();    
					verifyList=true;
					System.out.println("* Rooms available: \n" + rooms);
				} catch (IOException e) {
					System.err.println("ERROR: impossible to get rooms -- enterTheGame() from NGController Class.");
					e.printStackTrace();
				}
		}else 
			System.out.println("* Choose the nickname first.");
	}
	
	private void getDescriptionRoom() {
		try {
			ngClient.requestDescription(room);
		} catch (IOException e) {
			System.err.println("ERROR: imposible to get description -- getDescriptionRoom() from NGGameClient Class.");
			e.printStackTrace();

		}

	}
	
	private void enterTheGame() {

		if (verifyNick) {
			if (verifyList) { 
				try {
					if (ngClient.requestEnterGame(room)) {
						// If success, we change the state in order to accept new commands
						do {
							// We will only accept commands related to a room
							readGameCommandFromShell();
							processGameCommand();
						} while (currentCommand != NGCommands.COM_EXIT);
					}
				} catch (IOException e) {
					System.err.println("ERROR: impossible to enter the game -- enterTheGame() from NGController Class.");
					e.printStackTrace();
				}
			} else
				System.out.println("* Request the roomlist first.");
		}else
			System.out.println("* Choose the nickname first.");
	}
	
	private void disconnect() {
		try {	
			ngClient.sendDisconnect();
		} catch (IOException e) {
			System.err.println("ERROR: imposible disconnect -- disconnect() from NGController Class.");
			e.printStackTrace();
		}
	}



	// MÉTODO PARA PROCESAR COMANDOS DENTRO DEL JUEGO
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	private void processGameCommand() {
		switch (currentCommand) {
		case NGCommands.COM_RULES:
			System.out.println(rules); //mostraremos las reglas (siempre que el cliente lo pida) que previamente se han actualizado cuando entramos a una room
			break;
		//case NGCommands.COM_STATUS:
		//	break;
		case NGCommands.COM_ANSWER:
			if (verifyTurn)
				processChallenge();
			else 
				System.out.println("	Wait your turn.");
			break;
		case NGCommands.COM_SOCKET_IN:
			// In this case the user did not provide a command but an incoming message was
			// received from the server
			processGameMessage();
			break;
		case NGCommands.COM_PLAY_AGAIN:
			playAgain();
			break;
		case NGCommands.COM_EXIT:
			exitTheGame();

		}
	}

	
	// MÉTODOS UTILIZADOS DENTRO DE LA ROOM 
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	private void processChallenge() {
		// In case we have to send an answer we will wait for the response to display it
		try {
			ngClient.sendAnswer(answer);
		} catch (IOException e) {
			System.err.println("ERROR: imposible to send the answer -- processChallenge() from NGGameClient Class.");
			e.printStackTrace();
		}
	}
	
	private void playAgain() {
		// Notificamos al servidor que el cliente desea jugar otra partida (una revancha, por ejemplo)
		try {
			ngClient.sendPlayAgain();
		} catch (IOException e) {
			System.err.println("ERROR: imposible to play again -- playAgain() from NGGameClient Class.");
			e.printStackTrace();
		}
	}
	
	private void exitTheGame() {
		
		// Notificamos al servidor que el cliente va a abandonar la sala
		try {
			ngClient.sendExitGame();
			System.out.println("\n	You are out of the room.");
		} catch (IOException e) {
			System.err.println("ERROR: imposible to leave the room -- exitTheGame() from NGGameClient Class.");
			e.printStackTrace();
		}
	}

	// Muestra por pantalla los mensajes recibidos durante la ejecución del juego
	private void processGameMessage() {
		// This method processes the incoming message received when the shell was
		// waiting for a user command

		try {
			// Vamos a recibir el mensaje y según el tipo se ejecutará un método u otro (misma estrategia que en la ServerThread)
			NGMessage message = ngClient.checkGameMessage();
			
			switch (message.getOpcode()) {
				case NGMessage.OP_GAME_AND_RULES:
					// extraemos la información de la room y la mostramos
					NGGameInfoMessage info = (NGGameInfoMessage) message;	 					    
					room = info.getGame();            	       //Cuando ingresamos en la room el servidor nos manda un mensaje 
					rules = info.getRules();              	   //con el nombre de la room a la que hemos entrado, las reglas del juego
					System.out.println("\n	" + room  + "\n\n" + rules + "\n" );
					break;
					
				case NGMessage.OP_CHALLENGE:
					// extraemos la pregunta y la mostramos por pantalla
					NGStringMessage question = (NGStringMessage) message;
					System.out.println("\n" + question.getText()  + "\n");
					verifyTurn = true;
					break;
				
				case NGMessage.OP_STATUS:
				case NGMessage.OP_SCORE:
				case NGMessage.OP_ROOMLIST:
				case NGMessage.OP_DESCRIPTION:
					NGStringMessage text = (NGStringMessage) message;
					System.out.println(text.getText());
					break;	
					
				case NGMessage.OP_ANSWER_REC:	
				case NGMessage.OP_WAIT_TURN:
				case NGMessage.OP_TIMEOUT:
					NGStringMessage timeout = (NGStringMessage) message;
					System.out.println(timeout.getText());
					verifyTurn = false;
					break;	
					
				case NGMessage.OP_PLAY_AGAIN_OR_EXIT:
					NGStringMessage mss = (NGStringMessage) message;
					System.out.println("\n" + mss.getText() + "\n");
					// habilitamos el uso de los comandos
					verifyExit = true;
					verifyAgain = true;
					break;
					
				case NGMessage.OP_EXIT_GAME:
					System.out.println("\n	You are out of the room.");
					setCurrentCommand(NGCommands.COM_EXIT);	// necesario para que no aparezca (nanoGames-room) ya que puede dar lugar a confusión
					break;
					
				default:
					break;
			}
			
			
		} catch (IOException e) {
			System.err.println("ERROR: imposible to process the game message -- processGameMessage() from NGGameClient Class.");
			e.printStackTrace();
		}
			
	}



	// MÉTODO PARA COMUNICARSE CON EL BRÓKER
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Method to obtain the token from the Broker
	private void getTokenAndDeliver() {

		// We try to obtain a token from the broker
		// There will be a max number of attempts
			try {
				token = this.brokerClient.getToken(MAX_NUMBER_OF_ATTEMPTS);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		
		// If we have a token then we will send it to the game server
		if (token != 0) {
			try {
				// We initialize the game client to be used to connect with the name server
				ngClient = new NGGameClient(serverHostname);

				// We send the token in order to verify it
				if (!ngClient.verifyToken(token)) {
					System.out.println("* Invalid token.");
					token = 0;
				}//else  System.out.println("* Valid token.");
				
			} catch (IOException e) {
				System.out.println("* Check your connection, the game server is not available.");
				token = 0;
			}
		} else
			System.err.println("ERROR: Broker's token not received (number of attempts exceeded). -- getTokenAndDeliver() from NGController Class.");

	}

	public boolean sendToken() {
		// We simulate that the Token is a command provided by the user in order to
		// reuse the existing code
		//System.out.println("* Obtaining the token...");
		setCurrentCommand(NGCommands.COM_TOKEN);
		processCommand();
		return (token != 0);
	}
	
	
	
	// MÉTODOS DEL SHELL
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	public void readGameCommandFromShell() {
		// We ask for a new game command to the Shell (and parameters if any)
		shell.readGameCommand(ngClient);
		setCurrentCommand(shell.getCommand());
		setCurrentCommandArguments(shell.getCommandArguments());
	}

	public void readGeneralCommandFromShell() {
		// We ask for a general command to the Shell (and parameters if any)
		shell.readGeneralCommand();
		setCurrentCommand(shell.getCommand());
		setCurrentCommandArguments(shell.getCommandArguments());
	}


	public boolean shouldQuit() {
		return currentCommand == NGCommands.COM_QUIT;
	}

}
