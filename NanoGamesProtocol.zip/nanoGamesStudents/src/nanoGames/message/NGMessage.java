package nanoGames.message;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class NGMessage {
	//     "<(\\w+?)>(.*?)</\\1>"       EXPRESIÃ“N GENÃ‰RICA
	//     "<(\\w+?)>((.|\\n)*?)</\\1>"    EXPRESIÃ“N PARA LEER TAMBIÃ‰N SALTOS DE LÃ�NEA
	protected static String regexMessage = "<message((.|\\n)*?)</message>";
	protected static String regexOperation = "<operation>(.*?)</operation>";
	
	protected static Integer opcode;
	
	public static final int OP_SEND_TOKEN = 1;
	public static final int OP_TOKEN_OK = 2;
	public static final int OP_TOKEN_NOT_OK = 3;
	
	public static final int OP_SEND_NICK = 4;
	public static final int OP_NICK_OK = 5;
	public static final int OP_NICK_NOT_OK = 6;
	
	public static final int OP_DESCRIPTION = 7;
	public static final int OP_REQ_ROOMLIST = 8;
	public static final int OP_ROOMLIST = 9; 
	
	public static final int OP_DISCONNECT = 10;
	
	public static final int OP_ENTER_GAME = 11;
	public static final int OP_ENTER_GAME_OK = 12;
	public static final int OP_ENTER_GAME_NOT_OK = 13;
	
	public static final int OP_GAME_AND_RULES = 14;
	
	public static final int OP_STATUS = 15;
	
	public static final int OP_CHALLENGE = 16; 
	public static final int OP_ANSWER = 17; 
	public static final int OP_ANSWER_REC = 18;
	public static final int OP_WAIT_TURN = 19;
	public static final int OP_TIMEOUT = 20;
	
	public static final int OP_SCORE = 21; 
	
	public static final int OP_PLAY_AGAIN_OR_EXIT = 22; 
	public static final int OP_EXIT_GAME = 23;
	public static final int OP_PLAY_AGAIN = 24;

	
	//Returns the opcode of the message
	public Integer getOpcode() {
		return opcode;
	}

	//Method to be implemented specifically by each subclass of NGMessage
	public abstract String getStringMessage();
   
	//Reads the opcode of the incoming message and uses the subclass to parse the rest of the message
	public static NGMessage readMessageFromSocket(DataInputStream dis) throws IOException {   //dis lectura, dos escritura
		
		// COMPROBAMOS EL CÃ“DIGO DEL MENSAJE
		
		String ms  = dis.readUTF(); //mensaje hasta 65k caracteres sino utilizar el bufferReader y en cada mensaje aÃ±adir \n para que todos los mensajes se escriban en una linea

		Pattern pat1 = Pattern.compile(regexMessage);
		Matcher mat1 = pat1.matcher(ms);
		
		Pattern pat2 = Pattern.compile(regexOperation);
		Matcher mat2 = pat2.matcher(ms);
		
		if (mat1.find() && mat2.find()){
			String op = mat2.group(1);
			opcode = Integer.parseInt(op);
		}
		
		
		//We use the operation to differentiate among all the subclasses
		switch (opcode) { 
		case (OP_SEND_TOKEN): {
			return NGTokenMessage.readFromString(opcode, ms);
		}
		case (OP_TOKEN_OK): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_TOKEN_NOT_OK): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_SEND_NICK): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_NICK_OK): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_NICK_NOT_OK): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_DESCRIPTION): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_REQ_ROOMLIST): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_ROOMLIST): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_DISCONNECT): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_ENTER_GAME): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_ENTER_GAME_OK): {
			return NGStringMessage.readFromString(opcode, ms);		
		}
		case (OP_ENTER_GAME_NOT_OK): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_GAME_AND_RULES): {
			return NGGameInfoMessage.readFromString(opcode, ms);
		}
		case (OP_EXIT_GAME): {
			return NGControlMessage.readFromString(opcode);
		}		
		case (OP_STATUS): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_CHALLENGE): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_ANSWER): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_ANSWER_REC): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_SCORE): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_PLAY_AGAIN_OR_EXIT): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_PLAY_AGAIN): {
			return NGControlMessage.readFromString(opcode);
		}
		case (OP_WAIT_TURN): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		case (OP_TIMEOUT): {
			return NGStringMessage.readFromString(opcode, ms);
		}
		default:
			System.err.println("Unknown message type received:" + "invalid_code");
		}
		return null;
	}

	
	public static NGMessage makeTokenMessage(int code, Long token) throws IOException{
		return (new NGTokenMessage(code, token));
	}
	
	public static NGMessage makeControlMessage(int code) throws IOException{
		return (new NGControlMessage(code));
	}
	
	public static NGMessage makeStringMessage(int code, String text) throws IOException{
		return (new NGStringMessage(code, text));
	}
	
	public static NGMessage makeGameAndRulesMessage(int code, String game, String rules) throws IOException{
		return (new NGGameInfoMessage(code, game, rules));
	}


}
