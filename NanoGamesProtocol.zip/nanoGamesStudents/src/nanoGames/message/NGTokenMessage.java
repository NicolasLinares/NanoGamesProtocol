package nanoGames.message;


import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
Include here the specification of this particular message
*/
//TODO
public class NGTokenMessage extends NGMessage {
	private static String regMessage = "<message>(.*?)</message>";
	private static String regToken = "<token>(.*?)</token>";
	private String token;

	public NGTokenMessage(int code, Long token) {
		opcode = code;
		this.token = token.toString();
	}

	//TODO Replace this method according to your specific message
	public Long getToken() {
		return Long.parseLong(token);
	}
	
	@Override
	public String getStringMessage() {
		return "<message> "
							+ "<operation>" + opcode.toString() + "</operation>" 
							+ "<token>" + this.token + "</token>" +
					"</message>";
	}
	
	public static NGTokenMessage readFromString(int code, String ms) throws IOException {
				
		//CHECK THE REST OF THE MESSAGE
		Pattern pat1 = Pattern.compile(regMessage);
		Matcher mat1 = pat1.matcher(ms);

		Pattern pat2 = Pattern.compile(regToken);
		Matcher mat2 = pat2.matcher(ms);
		
		if (mat1.find() && mat2.find()) {
			return new NGTokenMessage(code, Long.parseLong(mat2.group(1)));
		}else 
			return null;

	}


}














