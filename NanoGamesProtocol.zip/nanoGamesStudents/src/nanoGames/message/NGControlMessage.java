package nanoGames.message;

public class NGControlMessage extends NGMessage {

	public NGControlMessage(Integer code) {
		opcode = code;
	}
	
	@Override
	public String getStringMessage() {
		return "<message> "
							+ "<operation>" + opcode.toString() + "</operation>" +
					"</message>";
		
	}
	
	public static NGControlMessage readFromString(int code) {
		return new NGControlMessage(code);
	}

}






