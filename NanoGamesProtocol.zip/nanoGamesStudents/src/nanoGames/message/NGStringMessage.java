package nanoGames.message;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NGStringMessage  extends NGMessage {

	private String text;
	private static String regexMessage = "<message>((.|\\n)*?)</message>";
	private static String regexText = "<text>((.|\\n)*?)</text>";
	
	public NGStringMessage(Integer code, String text) {
		opcode = code;
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
	
	@Override
	public String getStringMessage() {
		return "<message> "
				+ "<operation>" + opcode.toString() + "</operation>" 
				+ "<text>" + this.text + "</text>" +
		"</message>";
	}

	public static NGMessage readFromString(Integer code, String ms) {
				
		//CHECK THE REST OF THE MESSAGE
		Pattern pat1 = Pattern.compile(regexMessage);
		Matcher mat1 = pat1.matcher(ms);

		Pattern pat2 = Pattern.compile(regexText);
		Matcher mat2 = pat2.matcher(ms);
		
		if (mat1.find() && mat2.find()) {
			
			return new NGStringMessage(code, mat2.group(1));
		}else 
			return null;
	}

}

