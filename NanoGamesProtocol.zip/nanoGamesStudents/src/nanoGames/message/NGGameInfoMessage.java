package nanoGames.message;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NGGameInfoMessage  extends NGMessage {

	private String game;
	private String rules;
	
	private static String regexMessage = "<message>((.|\\n)*?)</message>";
	private static String regexGame = "<game>((.|\\n)*?)</game>";
	private static String regexRules = "<rules>((.|\\n)*?)</rules>";
	
	public NGGameInfoMessage(Integer code, String game, String rules) {
		opcode = code;
		this.game = game;
		this.rules = rules;
	}
	
	public String getGame() {
		return game;
	}
	public String getRules() {
		return rules;
	}
	
	@Override
	public String getStringMessage() {
		return "<message> "
				+ "<operation>" + opcode.toString() + "</operation>" 
				+ "<game>" + this.game + "</game>" 
				+ "<rules>" + this.rules + "</rules>" +
		"</message>";
	}

	public static NGMessage readFromString(Integer code, String ms) {
				
		//CHECK THE REST OF THE MESSAGE
		Pattern pat1 = Pattern.compile(regexMessage);
		Matcher mat1 = pat1.matcher(ms);

		Pattern pat2 = Pattern.compile(regexGame);
		Matcher mat2 = pat2.matcher(ms);
		
		Pattern pat3 = Pattern.compile(regexRules);
		Matcher mat3 = pat3.matcher(ms);
		
		if (mat1.find() && mat2.find() && mat3.find()) {
			
			return new NGGameInfoMessage(code, mat2.group(1), mat3.group(1) );
		}else 
			return null;
	}

}
