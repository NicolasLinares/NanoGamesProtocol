package nanoGames.server;

import java.util.HashMap;

import nanoGames.server.roomManager.NGRoomManager;
import nanoGames.server.roomManager.NGRoomStatus;

/**
 * This class contains the general status of the whole server (without the logic related to particular games)
 */
class NGServerManager {
	
	//Players registered in this server
	private HashMap<String, NGPlayerInfo> players;
	//Current rooms and their related RoomManagers
	//Data structure to relate rooms and RoomManagers
	private HashMap<Integer, NGRoomManager> roomsMap;
	
	// Clave de una room
	private int idRoom;
	
	NGServerManager() {
		this.players = new HashMap<String, NGPlayerInfo>();
		this.roomsMap = new HashMap<Integer, NGRoomManager>();  //<Id, Room>
		this.idRoom = 0;
	}

	
	public synchronized void registerRoomManager(NGRoomManager rm) {
		//When a new room manager is registered we assigned it to a room 
		this.idRoom++;
		this.roomsMap.put(idRoom, rm);
	}
	
	//Returns the set of existing rooms
	public synchronized String getRoomList() {
		String lista = "";
		for (Integer key : roomsMap.keySet()) {
			
			NGRoomManager rm = roomsMap.get(key);
			
			lista += "	("+ key.toString() + ")   " + rm.getRoomName() + "    Players[" + rm.getPlayersInRoom()+ "/"+ rm.maxPlayers() + "]\n";
		}
		return lista;
	}
	
	public synchronized int getListPlayers() {
		return players.size();
	}
	
	// Devuelve la descripción de la room pasada como parámetro
	public synchronized String getRoomDescription(Integer room) {
		//We make use of the RoomManager to obtain an updated description of the room
		return this.roomsMap.get(room).getDescription();
	}
	
	// Comprobamos si se encuentra el nick
	public synchronized boolean checkNick(String nick) {
		if (!this.players.containsKey(nick)) {
			return true;
		}else return false;
	}
	
	// Añadimos al jugador a la lista
	public synchronized void addPlayer(NGPlayerInfo player) {
		this.players.put(player.nick, player);

	}
	
	
	// Intentamos conectarlo a una room, si es posible devolverá la room con la que se ha conectado
	public synchronized NGRoomManager enterRoom(NGPlayerInfo p, Integer room) {
		NGRoomManager rm = roomsMap.get(room);
		if (rm.registerPlayer(p))
			return rm;
		else 
			return null;
	}
	
	public synchronized boolean checkRoomExists(Integer room) {
		NGRoomManager rm = roomsMap.get(room);
		if ( rm !=  null) {
			return true;
		} else 
			return false;
	}
	
	// Dos formas de eliminar al jugador del server, por objeto (player) o por nombre (nick)
	public synchronized void removePlayer(NGPlayerInfo player) {
		this.players.remove(player);
	}
	
	public synchronized void removePlayer(String  nick) {
		this.players.remove(nick);
	}
	
	// Para borrar al jugador de la room
	public synchronized void leaveRoom(NGPlayerInfo p, Integer room) {
		this.roomsMap.get(room).removePlayer(p);
	}
	
	
	
	public synchronized String checkStatus(NGPlayerInfo player, NGRoomManager room) {
		NGRoomStatus status = room.getStatusRoom();

		// S_WAITING (0): se quedará en el bucle hasta que el estado haya cambiado
		if ( status.statusNumber != 0 && player.status != status.statusNumber) {
			
			// S_SKIP_STATUS
			if (status.statusNumber == 5) 
				return "skip";
			
			// S_NOTIFY_EXIT
			else if (status.statusNumber == 4) {
				// Actualizamos el estado del jugador y de la sala
				status.statusNumber = status.S_WAITING;
				player.status = status.S_NOTIFY_EXIT;
			} 
					
			// S_START_GAME
			// S_CHECK_ROUND_WINNER
			// S_END_GAME
			return room.getStatusRoom().status;
			
		}else return null;
	}
	
	
	
}
