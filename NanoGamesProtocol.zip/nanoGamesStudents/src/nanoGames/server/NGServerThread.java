package nanoGames.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import nanoGames.broker_client.BrokerClient;
import nanoGames.message.NGControlMessage;
import nanoGames.message.NGGameInfoMessage;
import nanoGames.message.NGMessage;
import nanoGames.message.NGStringMessage;
import nanoGames.message.NGTokenMessage;
import nanoGames.server.roomManager.NGChallenge;
import nanoGames.server.roomManager.NGRoomManager;


/**
 * A new thread runs for each connected client
 */
public class NGServerThread extends Thread {


	private static final int MAX_NUMBER_OF_ATTEMPTS = 5;


	// Time difference between the token provided by the client and the one obtained
	// from the broker directly
	private static final long TOKEN_THRESHOLD = 1500; // 15 seconds
	// Socket to exchange messages with the client
	private Socket socket = null;
	// Global and shared manager between the threads
	private NGServerManager serverManager = null;
	// Input and Output Streams
	private DataInputStream dis;
	private DataOutputStream dos;
	// Utility class to communicate with the Broker
	BrokerClient brokerClient;
	// Current player
	NGPlayerInfo player;
	// Current RoomManager (it depends on the room the user enters)
	NGRoomManager roomManager = null;
	
	// Guardamos el número identificador de la room cuando la pedimos
	private Integer idRoom = null;
	// Variable que hace referencia al comando exit para salir de una room
	private boolean exit = false;
    // variable que mantiene la conexión con el servidor
	private boolean connectionAlive =  true;
    // variable que se actualiza cuando hemos entrado a la room (utilizada para cuando escribimos una room que no es válida)
	private boolean room_ok = false;
	
	// variable para asegurar que el estado se envía solo una vez
	private boolean statusSent = false;
	
	// Variable para guardar el oponente
	private NGPlayerInfo opp = null;
	
	
	NGMessage mss;
	
	public NGServerThread(NGServerManager manager, Socket socket, String brokerHostname) {
		// Initialization of the thread
		this.brokerClient = new BrokerClient(brokerHostname);
		this.serverManager = manager;
		this.socket = socket;
	
	}
	
	// Main loop
	public void run() {
		try {
			// We obtain the streams from the socket
			dis = new DataInputStream(socket.getInputStream());
			dos = new DataOutputStream(socket.getOutputStream());

			// Primer paso: verificar el token
			receiveAndVerifyToken();
			// Segundo paso: verificar el nick
			receiveAndVerifyNickname();

			// MÉTODO PRINCIPAL DEL FUNCIONAMIENTO DE LOS JUEGOS (FUERA DE LA ROOM):
			//----------------------------------------------------------------------
			// While the connection is alive...
			while (connectionAlive) {
				// Podemos elegir entre mostrar las rooms disponibles (roomlist), cerrar la conexión con el servidor (quit) o entrar a una room (enter <N>)
				messageController();
				// Nos encontramos dentro de la room si es válida
				if (room_ok) 
					processRoomMessages(); // (DENTRO DE LA ROOM)				
			}
			
		} catch (Exception e) {
			// If an error occurs with the communications the user is removed from all the
			// managers and the connection is closed
			
			try {
				// Debemos borrarlo de la lista de jugadores del ServerManager y la RoomManager
				System.out.println("The connection with the client " + socket.getInetAddress().toString() + ":" + socket.getPort() + " has been unexpectedly closed");
				playerDisconnect();
				socket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
		}
		
		// Close the socket
		try {
			
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	
	// MÉTODO PARA ENVIAR UN MENSAJE DE CUALQUIER TIPO
	//--------------------------------------------------------------------------------------------------------------------
	private void sendMss(int codeOP, String message) throws IOException {
		
		switch (codeOP) {
		
			case NGMessage.OP_ENTER_GAME_OK:
			case NGMessage.OP_ENTER_GAME_NOT_OK:
			case NGMessage.OP_DESCRIPTION:
			case NGMessage.OP_CHALLENGE:
			case NGMessage.OP_STATUS:
			case NGMessage.OP_ANSWER_REC:
			case NGMessage.OP_WAIT_TURN:
			case NGMessage.OP_TIMEOUT:
			case NGMessage.OP_PLAY_AGAIN_OR_EXIT:
				mss = (NGStringMessage) NGMessage.makeStringMessage(codeOP, message);
				break;
			
				
			case NGMessage.OP_GAME_AND_RULES:
				System.out.println("* Sending information of the room "  + socket.getInetAddress().toString() + ":" + socket.getPort());
				mss = (NGGameInfoMessage) NGMessage.makeGameAndRulesMessage(NGMessage.OP_GAME_AND_RULES, roomManager.getRoomName(), roomManager.getRules());	
				break;
			case NGMessage.OP_SCORE:
				mss = (NGStringMessage) NGMessage.makeStringMessage(NGMessage.OP_SCORE, "	SCORE " + player.nick + " : " + player.score + "\n	SCORE " + opp.nick + " : " + opp.score);
				break;
			case NGMessage.OP_ROOMLIST:
				System.out.println("* Request to get rooms list from "  + socket.getInetAddress().toString() + ":" + socket.getPort());
				mss = (NGStringMessage) NGMessage.makeStringMessage(codeOP, serverManager.getRoomList());
				break;	
				
			case NGMessage.OP_TOKEN_OK:
			case NGMessage.OP_TOKEN_NOT_OK:
			case NGMessage.OP_NICK_OK:
			case NGMessage.OP_NICK_NOT_OK:
			case NGMessage.OP_EXIT_GAME:
				mss = (NGControlMessage) NGMessage.makeControlMessage(codeOP);
				break;
				
			default:
				break;
		}
		
		String rawMessage = mss.getStringMessage();
		dos.writeUTF(rawMessage);
	}
	
	
	
	
	// MÉTODOS UTILIZADOS FUERA DE LA ROOM
	//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	
	// Receive and verify Token
	private void receiveAndVerifyToken() throws IOException {
		boolean tokenVerified = false;
		while (!tokenVerified) {

			NGTokenMessage message = (NGTokenMessage) NGMessage.readMessageFromSocket(dis); 
			long token = message.getToken();
			
			// Extraemos el token del mensaje
			long tokenAux = this.brokerClient.getToken(MAX_NUMBER_OF_ATTEMPTS); 
			if (tokenAux != 0) {
				System.out.println("* Token received from "  + socket.getInetAddress().toString() + ":" + socket.getPort());
				// Comprobamos si el token es válido y enviamos su respectivo mensaje
				if (tokenAux - token < TOKEN_THRESHOLD) {
					tokenVerified = true;
					System.out.println("Valid Token " + token);
					
					sendMss(NGMessage.OP_TOKEN_OK, "");
				} else {
					System.out.println("Invalid Token " + token);
					
					sendMss(NGMessage.OP_TOKEN_NOT_OK, "");
				}
			} else
				System.err.println("ERROR: Broker's token not received (number of attempts exceeded) -- receiveAndVerifyToken() from NGServerThread Class");

		}

	}

	// We obtain the nick and we request the server manager to verify if it is duplicated
	private void receiveAndVerifyNickname() throws IOException {
		boolean nickVerified = false;

		while (!nickVerified) {
			// Obtenemos el nick del mensaje
			NGStringMessage message = (NGStringMessage) NGMessage.readMessageFromSocket(dis);
			String nick = message.getText();
			System.out.println("* Nick received from " + socket.getInetAddress().toString() + ":" + socket.getPort());

			// Comprobamos si el nick se encuentra ya elegido
			if (this.serverManager.checkNick(nick)) {
				
				// Si el nombre no se encuentra repetido, nick válido, creamos el jugador
				this.player = new NGPlayerInfo(nick);
				this.serverManager.addPlayer(player);
				
				nickVerified = true;
				System.out.println("Valid nick \"" + player.nick + "\"");
				sendMss(NGMessage.OP_NICK_OK, "");
	
			}else {
				// Sino enviamos nick duplicado
				System.out.println("Duplicated nick \"" + player.nick  + "\"");
				sendMss(NGMessage.OP_NICK_NOT_OK, "");

			}
		}
	}



	private void requestEnterRoom(NGStringMessage message) throws IOException {
		
		idRoom = Integer.parseInt(message.getText());
		
		System.out.println("* Request to enter the room " + idRoom);

		// 1) Comprobamos que existe la room, enviando un aviso específico si no existe
		if(serverManager.checkRoomExists(idRoom)) {
			
			// 2) Comprobamos si la room está completa, en cuyo caso envía otro aviso al cliente
			roomManager = serverManager.enterRoom(player, idRoom);
			
			if (roomManager == null) {
				System.out.println("Limit of players reached");
				sendMss(NGMessage.OP_ENTER_GAME_NOT_OK, "* Limit of players reached, try it again later.");
				
			}else {
				// 3) Si todo está correcto, avisamos al cliente que ya se encuentra en la room
				System.out.println("Player \""+ player.nick +"\" is in the room " + idRoom);
				room_ok = true;
				sendMss(NGMessage.OP_ENTER_GAME_OK, "	You are in the room.");
			}
			
		} else {
			System.out.println("Room doesn't exist");
			sendMss(NGMessage.OP_ENTER_GAME_NOT_OK, "* Room doesn't exist, choose another option.");

		}		
	}
	
	private void requestDescription(NGStringMessage message) throws IOException {
		
		idRoom = Integer.parseInt(message.getText());
		
		System.out.println("* Request description about the room " + idRoom);

		// 1) Comprobamos que existe la room, enviando un aviso específico si no existe
		if(serverManager.checkRoomExists(idRoom)) {
			
			String descr = serverManager.getRoomDescription(idRoom);
			sendMss(NGMessage.OP_DESCRIPTION, descr);
			
		} else {
			System.out.println("Room doesn't exist");
			sendMss(NGMessage.OP_DESCRIPTION, "* Room doesn't exist, choose another option.");
		}		
	}
	

	private void playerDisconnect() throws IOException {
		
		// Lo borramos de la room solo si estaba en ella y si no ha sido borrado antes
		if (roomManager != null )
			serverManager.leaveRoom(player, idRoom);
		
		// Lo borramos de la lista de jugadores del servidor solo si estaba en ella
		if (player != null)
			serverManager.removePlayer(player.nick);

		// Cerramos la conexión
		connectionAlive = false;
		
		System.out.println("* The client \"" + player.nick + "\" has disconnected  from " + socket.getInetAddress().toString() + ":" + socket.getPort());

	}
	
	
	// MÉTODO PRINCIPAL DEL FUNCIONAMIENTO DE LOS JUEGOS (DENTRO DE UNA ROOM):
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Method to process messages received when the player is in the room
	private void processRoomMessages() throws IOException {
		// First we send the rules and the initial status
		
		sendMss(NGMessage.OP_GAME_AND_RULES, "");
		
		sendStatus(); // Espera a que el segundo jugador entre en la room y se pueda comenzar el juego
		
		this.opp = roomManager.getOpponent(player);
		
		// Now we check for incoming messages, status updates and new challenges
		exit = false;
		while (!exit) {
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// Ignore
			}
			
			// Comprobamos si es nuestro turno, en el caso de que el juego no tenga turnos no hace nada.
			checkTurn();			
			
			// Enviamos el challenge y obtenemos su respuesta
			processNewChallenge(roomManager.getChallenge());
						
			// Esperamos un nuevo estado
			sendStatus();
						
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// Ignore
			}
			
			// Enviamos puntuaciones después de cada challenge
			sendMss(NGMessage.OP_SCORE, "");
			
			// Comprobamos ganador.
			// Si ya se han respondido todas las preguntas: 
			//		 (1) indicamos quién ha ganado la partida.
			// 		 (2) preguntamos si quieren volver a jugar o salir de la room.
			if (roomManager.checkGameWinner(player)){
				sendStatus();
				sendMss(NGMessage.OP_PLAY_AGAIN_OR_EXIT, "	* Do you want to play again? *\n		<again> / <exit>");
				messageControllerGame();
			}
				
		
		}	
	}
	
	// MÉTODOS UTILIZADOS DENTRO DE LA ROOM 
	//-----------------------------------------------------------------------------------------------------------------------------------------------------------

	// Envía el estado si ha cambiado
	private void sendStatus() throws IOException  {
		
		while(!statusSent) {
		
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			String actualStatus = serverManager.checkStatus(player, roomManager);
			if (actualStatus != "skip") {
				if (actualStatus != null ) {
					sendMss(NGMessage.OP_STATUS, actualStatus);

					statusSent = true;
				}
			} else // omitir el estado
				statusSent = true;
		}
		
		statusSent = false;		// para el próximo estado
	}

	
	private void checkTurn() throws IOException {
		
		// avisamos al jugador que no es su turno
		if (player.turn == false) {
			sendMss(NGMessage.OP_WAIT_TURN, "	Wait your turn.");
		}
			
		// si no es su turno realizamos una espera ocupada para bloquearlo, comprueba cada 100 ms 
		while (player.turn != true)
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// Ignore
			}
	}
	
	// Método para recibir la respuesta a un challenge
	private String receiveAnswer() throws IOException {

		NGStringMessage message = (NGStringMessage) NGMessage.readMessageFromSocket(dis); 
		System.out.println("Answer received from "+  socket.getInetAddress().toString() + ":" + socket.getPort());
		return message.getText();
	}
	
	private void requestExitRoom() throws IOException {
		
		System.out.println("* Request to leave the room " + idRoom + " from " + socket.getInetAddress().toString() + ":" + socket.getPort());
		serverManager.leaveRoom(player, idRoom); //borramos al jugador de la room
		roomManager = null;
		exit = true; // para salir del bucle del juego y volver a la sala principal
		room_ok = false;
	}
	
	
	// MÉTODOS DE CONTROL DE MENSAJES FUERA DE LA ROOM Y DENTRO DE LA ROOM
	//------------------------------------------------------------------------------------------------------------------------------------------------------
	// Método que sirve para recibir un mensaje y que según el código de operación, poder ejecutar un procedimiento u otro
	private void messageController() throws IOException {

		NGMessage message = NGMessage.readMessageFromSocket(dis);
		int code = message.getOpcode();
		
		switch (code) {
			case NGMessage.OP_ENTER_GAME:
				requestEnterRoom((NGStringMessage)message);
				break;
			case NGMessage.OP_DISCONNECT:
				playerDisconnect();
				break;
			case NGMessage.OP_REQ_ROOMLIST:
				sendMss(NGMessage.OP_ROOMLIST, "");
				break;
			case NGMessage.OP_DESCRIPTION:
				requestDescription((NGStringMessage)message);
				break;
			default:
				break;
		}
	}
	
	// Método que sirve para recibir un mensaje y que según el código de operación, poder ejecutar un procedimiento u otro
	private void messageControllerGame() throws IOException {

		NGMessage message = NGMessage.readMessageFromSocket(dis);
		int code = message.getOpcode();
		
		switch (code) {
			case NGMessage.OP_EXIT_GAME:
				requestExitRoom();
				break;
				
			case NGMessage.OP_PLAY_AGAIN:
				// Espera a que el otro jugador conteste si quiere jugar de nuevo o no
				roomManager.controlEndGame(player);
				sendStatus();
				if (player.status == 4) {// 4: valor del estado (NGRoomSTATUS.S_NOTIFY_EXIT) que indica que como ha salido el oponente, este jugador debe ser echado de la room
					requestExitRoom();
					sendMss(NGMessage.OP_EXIT_GAME, "");
				}
				break;
			default:
				break;
		}
	}
	
	
	// TIMER
	//------------------------------------------------------------------------------------------------------------------------------------------------------
	private AtomicBoolean timeout_triggered = new AtomicBoolean();
	
	//Private class to implement a very simple timer
	private class Timeout extends TimerTask {

		@Override
		public void run() {		
			timeout_triggered.set(true);
		}
	}
	
	private void processNewChallenge(NGChallenge challenge) throws IOException {
		
		// We send the challenge to the client
		sendMss(NGMessage.OP_CHALLENGE, challenge.challenge);
		System.out.println("* Sending challenge " + roomManager.getRoomName() );
		
		// Now we set the timeout
		Timer timer = null;
		timeout_triggered.set(false);
		timer = new Timer();
		timer.schedule(new Timeout(), roomManager.getTimeout(), roomManager.getTimeout());
		boolean answerProvided = false;
		// Loop until an answer is provided or the timeout expires
		while (!timeout_triggered.get() && !answerProvided) {
			if (dis.available() > 0) {
				// The client sent a message
				String answer = receiveAnswer();
				// IF ANSWER Then call roomManager.answer() and proceed
				roomManager.answer(player, answer);
				sendMss(NGMessage.OP_ANSWER_REC, "	Answer received.");
				
				answerProvided = true;
				
				timer.cancel();

			} else		
				try {
					// To avoid a CPU-consuming busy wait
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// Ignore
				}
		}
				
		if (!answerProvided) {
		
			answerProvided = false;
			// The timeout expired
			// Avisamos al jugador que el tiempo a expirado
			
			System.out.println("TIMEOUT EXPIRED FROM " + socket.getInetAddress().toString() + ":" + socket.getPort());
			sendMss(NGMessage.OP_TIMEOUT, "	Timeout expired.");

			timer.cancel();

			roomManager.noAnswer(player);
		}
	}

		
}
