package nanoGames.server.roomManager;

import java.util.LinkedList;

import nanoGames.server.NGPlayerInfo;

public class RoomRockPaperScissorsLizardSpock extends NGRoomManager{
	
	
	private NGRoomStatus roomStatus; // estado global del juego que se irá actualizando, por ejemplo, cuando entra el segundo jugador
	private NGChallenge challenges;
	
	// Número de jugadores que admite el juego
	private static final int MAX_PLAYERS = 2;
	
	// Total de puntos necesarios para que el juego termine (siempre hay un ganador)
	private static final int MAX_SCORE = 3 ;	
	
	// Puntuación por cada respuesta correcta
	private static final int SC = 1;
	

	public RoomRockPaperScissorsLizardSpock() {
		
		this.gameTimeout = 10000; 
		
		this.rules = "	* Rules: \n"
					+ "	  - Scissors cuts Paper. \n"
					+ "	  - Paper covers Rock. \n"
					+ "	  - Rock crushes Lizard. \n"
					+ "	  - Lizard poisons Spock. \n"
					+ "	  - Spock smashes Scissors. \n"
					+ "	  - Scissors decapitates Lizard. \n"
					+ "	  - Lizard eats Paper. \n"
					+ "	  - Paper disproves Spock.\n"
					+ "	  - Spock vaporises Rock. \n"
					+ "	  - Rock crushes Scissors.";
		
		this.registrationName = ">> Rock, Paper, Scissors, Lizard, Spock <<";
				
		this.description = "   Win three times to get the victory. \n"
						 + "   The game begins automatically when the maximum number of players is reached. \n"
						 + "   Choose an option \"a <answer number> \" and good luck! \n"
						 + "   Time to respond: " + this.gameTimeout/1000 + " seconds.";
		
		
		this.players = new LinkedList<NGPlayerInfo>();
		
		this.roomStatus = new NGRoomStatus();
		this.challenges = new NGChallenge();
		
		gameWinner = null;
		mssRoundWinner = null;
		
		// contadores
		this.contCheck = 0;
		this.playersInRoom = 0;

		
	}

	@Override
	public int maxPlayers() {
		return MAX_PLAYERS;
	}

	@Override
	public int getSC() {
		return SC;
	}
	
	@Override
	public int getPlayersInRoom() {
		return playersInRoom;
	}

	public int getMaxScore() {
		return MAX_SCORE;
	}

	
	@Override
	public synchronized String getRules() {
		return rules;
	}
	
	@Override
	public synchronized NGRoomStatus getStatusRoom() {

		return roomStatus;
	}

	@Override
	public synchronized String getRoomName() {
		return registrationName;
	}

	@Override
	public synchronized String getDescription() {
		return description;
	}

	@Override
	public synchronized NGPlayerInfo getOpponent(NGPlayerInfo p) {
		for (NGPlayerInfo ngPlayerInfo : players) {
			if (ngPlayerInfo.nick != p.nick) return ngPlayerInfo;
		}
		return null;
	}
	
	@Override
	public synchronized NGChallenge getChallenge() {
		// En este caso el número del challenge no importa, ponemos 0, siempre es la misma pregunta
		this.challenges = new  NGChallenge( (short) 0 , "    * Choose option: \n     (1) Rock   (2) Paper   (3) Scissors   (4) Lizard   (5) Spock");
		return  challenges;
	}

	@Override
	public synchronized boolean registerPlayer(NGPlayerInfo p) {
		
		if (playersInRoom < MAX_PLAYERS) {
			playersInRoom++;
			players.add(p);
			
			// Se inicializan por si es la segunda vez que entran a la room
			p.score = 0;
			p.status = 0;
			p.turn = true; // como no hay turnos se ponen todos a true, no se modificará
			contCheck = 0;

			// el primero inicializa las variables del juego
			if (playersInRoom == 1) {
				gameWinner = null;
				mssRoundWinner = null;
			}	
			
			if (playersInRoom == MAX_PLAYERS) 
				this.roomStatus = new NGRoomStatus(roomStatus.S_START_GAME,  "		" + p.nick + " VS " + getOpponent(p).nick  + " \n	----------------------------\n		Are you ready?" );
			return true;
		}else 
			return false;
	}
	
	
	@Override
	public synchronized void noAnswer(NGPlayerInfo p) {
		p.lastAnswer = -1;

		contCheck ++;
		
		// El último que conteste a la pregunta cambiará el estado del juego
		if (contCheck == MAX_PLAYERS) {
			contCheck = 0; //reiniciamos el contador para la siguiente pregunta
			
			// El último procesa el ganador
			processRoundWinner(p);
		}else 
			this.roomStatus.statusNumber =  roomStatus.S_WAITING;
				
	}

	@Override
	public synchronized void answer(NGPlayerInfo p, String answer) {
		p.lastAnswer = Integer.parseInt(answer);

		contCheck++;
		
		// El último que conteste a la pregunta cambiará el estado del juego
		if (contCheck == MAX_PLAYERS) {
			contCheck = 0; //reiniciamos el contador para la siguiente pregunta
			
			// El último procesa el ganador
			processRoundWinner(p);
		}else 
			this.roomStatus.statusNumber =  roomStatus.S_WAITING;
			
	}


	@Override
	public synchronized void removePlayer(NGPlayerInfo p) {
		
		NGPlayerInfo opp = getOpponent(p);
		
		contCheck++;
		playersInRoom--;
		
		// en ambos casos mi rival sigue en la room:
		// opción 1: mi rival decide jugar de nuevo y yo después elijo salir
		// opción 2: yo salgo primero y mi rival todavía no ha decidido
		if (opp != null) 
			this.roomStatus = new NGRoomStatus(roomStatus.S_NOTIFY_EXIT,  "	Your opponent has leaved the room" );
		else 
			// el último en salir reinicia el estado de la room
			this.roomStatus.statusNumber = roomStatus.S_WAITING;
		
		players.remove(p);
		
	}
	
	
	@Override
	public synchronized void controlEndGame(NGPlayerInfo p) {
		
		NGPlayerInfo opp = getOpponent(p);

		contCheck++;
		
		// opción 1: el primero elige volver a jugar y se bloquea hasta que el segundo elija también volver a jugar y este último reinicia todo
		if (contCheck  == MAX_PLAYERS && opp != null) {
			this.roomStatus = new NGRoomStatus(roomStatus.S_START_GAME,  "	     PLAYING AGAIN\n	----------------------\n	     Are you ready?" );
			
			contCheck = 0;
			// Si van a volver a jugar reiniciamos todas las variables del juego
			gameWinner = null;
			mssRoundWinner = null;
			
			p.status = 0;
			p.score = 0;
			
			opp.status = 0;
			opp.score = 0;

		}else 
			// opción 2: si el primero elige jugar de nuevo se queda esperando a que el otro decida
			this.roomStatus.statusNumber = roomStatus.S_WAITING;

		// opción 3: mi rival ha decidido salir, pero yo quiero continuar, entonces notifico que mi rival ha salido
		if (contCheck  == MAX_PLAYERS && opp == null) {
			this.roomStatus = new NGRoomStatus(roomStatus.S_NOTIFY_EXIT,  "Your opponent has leaved the room" );
			contCheck = 0;
		}
		
	}
	
	@Override
	public synchronized boolean checkGameWinner(NGPlayerInfo p) {
		NGPlayerInfo opp = getOpponent(p);
		
		if ( p.score == MAX_SCORE || opp.score == MAX_SCORE) {
			
			if(p.score < opp.score) {
				gameWinner = opp.nick;
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	" + gameWinner + " won the game!" );
				
			} else if (p.score > opp.score) {
				gameWinner = p.nick;
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	" + gameWinner + " won the game!" );
				
			} else 
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	Tied game!" );
			
			return true;
		}else {
			// Si no hemos llegado al límite de preguntas entonces comienza otra ronda
			// y debemos reiniciar los estados de nuevo
			
			p.status = roomStatus.S_START_GAME;
			return false;
		}
			
		
	}
	
	@Override
	public synchronized void processRoundWinner(NGPlayerInfo p) {
		NGPlayerInfo opp = getOpponent(p);

			
		// Comprobación del ganador, donde cada opción tiene asociado un número
		switch (p.lastAnswer) {
			//(1)Rock 
			case 1:
						switch (opp.lastAnswer) {
							//(1)Rock
							case 1:
									mssRoundWinner = "	- Tied round -";
									gameWinner = "tied"; //empate
									break;
							//(2)Paper
							case 2:
									mssRoundWinner = "	- Paper covers Rock -";
									gameWinner = opp.nick;
									break;
							//(3)Scissors
							case 3:
									mssRoundWinner = "	- Rock crushes Scissors -";
									gameWinner = p.nick;	
									break;
							//(4)Lizard
							case 4:
									mssRoundWinner = "	- Rock crushes Lizard -";
									gameWinner = p.nick;
									break;
							//(5)Spock
							case 5:
									mssRoundWinner = "	- Spock vaporises Rock -";
									gameWinner = opp.nick;
									break;
							default:
									mssRoundWinner = "	- " + opp.nick + " has not responded -";
									gameWinner = p.nick;  // NO ANSWER opp
									break;
							}
						break;
			
		//(2)Paper
			case 2:
						switch (opp.lastAnswer) {
							//(1)Rock
							case 1:
									mssRoundWinner = "	- Paper covers Rock -";
									gameWinner = p.nick; 
									break;
							//(2)Paper
							case 2:
									mssRoundWinner = "	- Tied round -";
									gameWinner = "tied"; //empate
									break;
							//(3)Scissors
							case 3:
									mssRoundWinner = "	- Scissors cuts Paper -";
									gameWinner = opp.nick;
									break;
							//(4)Lizard
							case 4:
									mssRoundWinner = "	- Lizard eats Paper -";
									gameWinner = opp.nick;
									break;
							//(5)Spock
							case 5:
									mssRoundWinner = "	- Paper disproves Spock -";
									gameWinner = p.nick;
									break;
							default:
									mssRoundWinner = "	- " + opp.nick + " has not responded -";
									gameWinner = p.nick;  // NO ANSWER opp
									break;
						}
					break;
					
		//(3)Scissors
			case 3:
						switch (opp.lastAnswer) {
							//(1)Rock
							case 1:
									mssRoundWinner = "	- Rock crushes Scissors -";
									gameWinner = opp.nick;
									break;
							//(2)Paper
							case 2:
									mssRoundWinner = "	- Scissors cuts Paper -";
									gameWinner = p.nick; 
									break;
							//(3)Scissors
							case 3:
									mssRoundWinner = "	- Tied round -";
									gameWinner = "tied"; //empate
									break;
							//(4)Lizard
							case 4:
									mssRoundWinner = "	- Scissors decapitates Lizard -";
									gameWinner = p.nick;
									break;
							//(5)Spock
							case 5:
									mssRoundWinner = "	- Spock smashes Scissors -";
									gameWinner = opp.nick;
									break;
							default:
									mssRoundWinner = "	- " + opp.nick + " has not responded -";
									gameWinner = p.nick;  // NO ANSWER opp
									break;
						}
					break;
					
		//(4)Lizard
			case 4:
						switch (opp.lastAnswer) {
							//(1)Rock
							case 1:
									mssRoundWinner = "	- Rock crushes Lizard -";
									gameWinner = opp.nick; 
									break;
							//(2)Paper
							case 2:
									mssRoundWinner = "	- Lizard eats Paper -";
									gameWinner = p.nick; 
									break;
							//(3)Scissors
							case 3:
									mssRoundWinner = "	- Scissors decapitates Lizard -";
									gameWinner = opp.nick;
									break;
							//(4)Lizard
							case 4:
									mssRoundWinner = "	- Tied round -";
									gameWinner = "tied"; //empate
									break;
							//(5)Spock
							case 5:
									mssRoundWinner = "	- Lizard poisons Spock -";
									gameWinner = p.nick;
									break;
							default:
									mssRoundWinner = "	- " + opp.nick + " has not responded -";
									gameWinner = p.nick;  		// NO ANSWER opp
									break;
						}
					break;
						
		//(5)Spock
			case 5:
						switch (opp.lastAnswer) {
							//(1)Rock
							case 1:
									mssRoundWinner = "	- Spock vaporises Rock -";
									gameWinner = p.nick; 
									break;
							//(2)Paper
							case 2:
									mssRoundWinner = "	- Paper disproves Spock -";
									gameWinner = opp.nick; 
									break;
							//(3)Scissors
							case 3:
									mssRoundWinner = "	- Spock smashes Scissors -";
									gameWinner = p.nick;
									break;
							//(4)Lizard
							case 4:
									mssRoundWinner = "	- Lizard poisons Spock -";
									gameWinner = opp.nick;
									break;
							//(5)Spock
							case 5:
									mssRoundWinner = "	- Tied round -";
									gameWinner = "tied"; //empate
									break;
							default:
									mssRoundWinner = "	- " + opp.nick + " has not responded -";
									gameWinner = p.nick; // opp no ha contestado
									break;
						}
					break;
					
		// NO ANSWER p --> ( p.lastAnswer == -1)
			default:
					// si no ha contestado ninguno de los dos: no hay puntuación para ninguno y es empate
					if (opp.lastAnswer == -1) {
						
						mssRoundWinner = "	- Tied round -";
						gameWinner = "tied";
					// pero si opp ha contestado alguna de las preguntas: la puntuación es para opp
					} else if (opp.lastAnswer > 0 && opp.lastAnswer <= 5) {
						mssRoundWinner = "	- " + p.nick + " has not responded -";
						gameWinner = opp.nick;
					}
				
		}
		
		
		if (p.nick == gameWinner) 
			p.score += SC;
		if (opp.nick == gameWinner) 
			opp.score += SC;
		
		
		this.roomStatus = new NGRoomStatus(roomStatus.S_CHECK_ROUND_WINNER, mssRoundWinner );

		
	}

}
