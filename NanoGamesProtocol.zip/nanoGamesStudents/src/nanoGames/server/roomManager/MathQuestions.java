package nanoGames.server.roomManager;

import java.util.HashMap;
import java.util.LinkedList;

import nanoGames.server.NGPlayerInfo;

public class MathQuestions extends NGRoomManager{
	
	
	private NGRoomStatus roomStatus; // estado global del juego que se irá actualizando, por ejemplo, cuando entra el segundo jugador
	
	// Número de jugadores que admite el juego
	private static final int MAX_PLAYERS = 2; 
	
	// Total de preguntas que componen el juego
	private static final int TOTAL_QUESTIONS = 5;
	
	// Puntuación por cada respuesta correcta
	private static final int SC = 10;
	
	// Número de ronda actual por la que va el juego 
	private Integer rounds; 
	
	
	// Lista de las preguntas del juego
	private HashMap<Integer, NGChallenge> questions;


	public MathQuestions() {
		this.gameTimeout = 6000; 
		
		this.rules = "	* Rules: \n"
					+ "	  - You can only respond if its your turn. \n"
					+ "	  - Choose an option: \"a <answer> \".\n";

		
		this.registrationName = ">> MathQuestions <<";
				
		this.description = "   A question's game about math operations.   \n"
						 + "   For each correct question you win 10 points. \n"
						 + "   The game begins automatically when the maximum number of players is reached. \n"
						 + "   Choose an option \"a <answer number> \" and good luck! \n"
						 + "   Time to respond: " + this.gameTimeout/1000  + " seconds.";;
		
		this.players = new LinkedList<NGPlayerInfo>();
		this.questions = new HashMap<Integer, NGChallenge >();
		addQuestions();
		
		this.roomStatus = new NGRoomStatus();
		
		gameWinner = null;
		
		// contadores
		this.contCheck = 0;
		this.playersInRoom = 0;
		
	}

	@Override
	public synchronized int maxPlayers() {
		return MAX_PLAYERS;
	}

	@Override
	public int getSC() {
		return SC;
	}
	
	@Override
	public int getPlayersInRoom() {
		return playersInRoom;
	}
	
	public void addQuestions(){
	    // (número de la pregunta, pregunta con su respuesta)
		this.questions.put(1, new NGChallenge((short) 4, " 2 + 2 = ?"));
		this.questions.put(2, new NGChallenge((short) 24, " 4 * 6 = ?"));
		this.questions.put(3, new NGChallenge((short) 53, " 3 + 10 * 5 = ?"));
		this.questions.put(4, new NGChallenge((short) 7, " 20/4 + 2 = ?"));
		this.questions.put(5, new NGChallenge((short) 15, " (53 + 7)/4 = ?"));		
	/*	this.questions.put(6, new NGChallenge((short) 4, " 3 - 18 * 2 = ?"));
		this.questions.put(7, new NGChallenge((short) 24, " 8 * 9 = ?"));
		this.questions.put(8, new NGChallenge((short) 53, " 1 + 40 * 5 = ?"));
		this.questions.put(9, new NGChallenge((short) 7, " 200/4 + 2 * 3 = ?"));
		this.questions.put(10, new NGChallenge((short) 15, " (53 + 7) * (20 + 6) = ?"));	
		this.questions.put(12, new NGChallenge((short) 4, " 29 + 8/4 = ?"));
		this.questions.put(12, new NGChallenge((short) 24, " 13 * 10 + 10 = ?"));
		this.questions.put(13, new NGChallenge((short) 53, " 49 + 7 * 3 = ?"));
		this.questions.put(14, new NGChallenge((short) 7, " 20/5 + 25/5 = ?"));
		this.questions.put(15, new NGChallenge((short) 15, " 2 + 1 + 108 = ?"));	*/
		
	}
	

	@Override
	public synchronized String getRules() {
		return rules;
	}
	
	@Override
	public synchronized NGRoomStatus getStatusRoom() {
		return roomStatus;
	}

	@Override
	public synchronized String getRoomName() {
		return registrationName;
	}

	@Override
	public synchronized String getDescription() {
		return description;
	}

	@Override
	public synchronized NGPlayerInfo getOpponent(NGPlayerInfo p) {
		for (NGPlayerInfo ngPlayerInfo : players) {
			if (ngPlayerInfo.nick != p.nick) return ngPlayerInfo;
		}
		return null;
	}
	
	@Override
	public synchronized NGChallenge getChallenge() {
		return  questions.get(rounds);
	}

	
	@Override
	public synchronized boolean registerPlayer(NGPlayerInfo p) {
		if (playersInRoom < MAX_PLAYERS) {
			playersInRoom++;

			players.add(p);
			// Se inicializan por si es la segunda vez que entran a la room después de haber jugado
			p.score = 0;
			p.status = 0;
			
			// Control de turnos e iniciprocessRoomMessagesalización de las variables de la sala:
			if (playersInRoom == 1) {
				p.turn = true; // el primero que entra a la room tiene el primer turno 
				gameWinner = null;
				rounds = 1;
				contCheck = 0;

			}else
				p.turn = false;
			
			if (playersInRoom == MAX_PLAYERS) 
				this.roomStatus = new NGRoomStatus(roomStatus.S_START_GAME,  "		" + p.nick + " VS " + getOpponent(p).nick  + " \n	----------------------------\n		Are you ready?" );
			return true;
		}else 
			return false;
	}

		

	public synchronized void noAnswer(NGPlayerInfo p) {
		p.lastAnswer = -1;
		NGPlayerInfo opp = getOpponent(p);

		contCheck++;
		
		// El último que conteste a la pregunta cambiará el estado del juego
		if (contCheck == MAX_PLAYERS) {
			contCheck = 0; //reiniciamos el contador para la siguiente pregunta
			
			// El último procesa el ganador
			processRoundWinner(p);
		} else {
			roomStatus.statusNumber = roomStatus.S_WAITING;
			p.turn = false;
			opp.turn = true;
		}
		
	}

	@Override
	public synchronized void answer(NGPlayerInfo p, String answer) {
		p.lastAnswer = Integer.parseInt(answer);
		NGPlayerInfo opp = getOpponent(p);

		contCheck++;
		// El último que conteste a la pregunta cambiará el estado del juego
		if (contCheck == MAX_PLAYERS) {
			contCheck = 0; //reiniciamos el contador para la siguiente pregunta

			// El último procesa el ganador
			processRoundWinner(p);
		} else {
			roomStatus.statusNumber = roomStatus.S_WAITING;
			p.turn = false;
			opp.turn = true;
		}
		
	}


	@Override
	public synchronized void removePlayer(NGPlayerInfo p) {
		
		NGPlayerInfo opp = getOpponent(p);
		
		contCheck++;
		playersInRoom--;

		// en ambos casos mi rival sigue en la room
		// opción 1: mi rival decide jugar de nuevo y yo después elijo salir
		// opción 2: yo salgo primero y mi rival todavía no ha decidido
		if (opp != null) 
			this.roomStatus = new NGRoomStatus(roomStatus.S_NOTIFY_EXIT,  "	Your opponent has leaved the room" );
		else 
			// el último en salir reinicia el estado de la room
			roomStatus.statusNumber = roomStatus.S_WAITING;
		
		players.remove(p);
		
	}
	
	
	@Override
	public synchronized void controlEndGame(NGPlayerInfo p) {
		
		NGPlayerInfo opp = getOpponent(p);

		contCheck++;
		
		// opción 1: el primero elige volver a jugar y se bloquea hasta que el segundo elija también volver a jugar y este último reinicia todo
		if (contCheck == MAX_PLAYERS && opp != null) {
			this.roomStatus = new NGRoomStatus(roomStatus.S_START_GAME,  "	     PLAYING AGAIN\n	----------------------\n	     Are you ready?" );
			contCheck = 0;
			rounds = 1;
			// Reiniciamos sus variables por si vuelven a jugar
			p.status = 0;
			p.score = 0;
			
			opp.status = 0;
			opp.score = 0;

		}else 
			// opción 2: si el primero elige jugar de nuevo se queda esperando a que el otro decida
			roomStatus.statusNumber = roomStatus.S_WAITING;
		
		// opción 3: mi rival ha decidido salir, pero yo quiero continuar, entonces notifico que mi rival ha salido
		if (contCheck == MAX_PLAYERS && opp == null) {
			this.roomStatus = new NGRoomStatus(roomStatus.S_NOTIFY_EXIT,  "Your opponent has leaved the room" );
			contCheck = 0;
		}
		
	}
	
	@Override
	public synchronized boolean checkGameWinner(NGPlayerInfo p) {
		NGPlayerInfo opp = getOpponent(p);
		contCheck++;

		if ( rounds == TOTAL_QUESTIONS ) {

			if(p.score < opp.score) {
				gameWinner = opp.nick;
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	" + gameWinner + " won the game!" );
				
			} else if (p.score > opp.score) {
				gameWinner = p.nick;
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	" + gameWinner + " won the game!" );
				
			} else 
				this.roomStatus = new NGRoomStatus(roomStatus.S_END_GAME, "	Tied game!" );
			
			if (contCheck == MAX_PLAYERS) contCheck = 0;	
			
			return true;
		}else {
			// si no hemos llegado al límite de preguntas entonces comienza otra ronda
			// y debemos reiniciar los estados de nuevo
			p.status = roomStatus.S_START_GAME;
			if (contCheck == MAX_PLAYERS) {
				contCheck = 0;
				rounds++;
			}
			
			return false;
		}
			
		
	}
	
	@Override
	public synchronized void processRoundWinner(NGPlayerInfo p) {

		
		NGChallenge actualQ = this.questions.get(rounds);
		NGPlayerInfo opp = getOpponent(p);
		
		// Comprobamos si alguno ha acertado a la pregunta, sumando la puntuación en ese caso
		 
		if (p.lastAnswer == actualQ.getChallengeAnswer())
			p.score += SC;
		
		if (opp.lastAnswer == actualQ.getChallengeAnswer())
			opp.score += SC;
		
		// Vamos a omitir el mensaje de quién ha ganado la ronda, eso se verá en SCORE
		this.roomStatus.statusNumber = roomStatus.S_SKIP_STATUS; 

	}



}