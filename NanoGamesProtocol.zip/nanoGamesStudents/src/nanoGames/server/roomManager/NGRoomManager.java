package nanoGames.server.roomManager;


import java.util.LinkedList;

import nanoGames.server.NGPlayerInfo;

public abstract class NGRoomManager {
	
	String rules;
	String registrationName;
	String description;
	int gameTimeout; //In milliseconds
	
	
	// Variable que almacenará el ganador del juego
	protected String gameWinner;
	
	// Variable que almacenará el mensaje correspondiente a una ronda ganada/perdida/empatada
	protected String mssRoundWinner;
	
	// Variable utilizada para contar los jugadores que entran a consultar la room
	protected int contCheck;
	
	// Variable que almacena el número de jugadores que se encuentran en la room
	protected int playersInRoom;
	
	// Registro de los jugadores de la sala
	protected LinkedList<NGPlayerInfo> players;
	
	
	//the only requirement to add a player is that only MAX_PLAYERS are accepted
	public abstract boolean registerPlayer(NGPlayerInfo p);
	//Rules are returned
	public abstract String getRules();
	//The player provided no answer and we process that situation
	public abstract void noAnswer(NGPlayerInfo p);
	//The answer provided by the player has to be processed
	public abstract void answer(NGPlayerInfo p, String answer);
	//The player is removed (maybe the status has to be updated)
	public abstract void removePlayer(NGPlayerInfo p);
	//Returns the name of the game
	public abstract String getRoomName();
	//Returns the description of the room
	public abstract String getDescription();
	//Returns the current number of players in the room
	public abstract int getPlayersInRoom();
	
	public int getTimeout() {
		return gameTimeout;
	}
	

    //--------------------------------------------------------------------------------------------------------------------------------------------
	
	// Devuelve el máximo de jugadores permitidos en el juego
	public abstract int maxPlayers();
	
	// Puntuación que el juego le da a cada respuesta correcta
	public abstract int getSC();
	
	// Devuelve el nombre del oponente del jugador pasado como parámetro
	public abstract NGPlayerInfo getOpponent(NGPlayerInfo p);
	
	// Para obtener el estado actual
	public abstract NGRoomStatus getStatusRoom();
	
	// Para obtener el challenge
	public abstract NGChallenge getChallenge();
	
	// Comprueba el ganador de la ronda
	public abstract void processRoundWinner(NGPlayerInfo p);
	
	// Comprueba el ganador del juego, aquel que llega primero a limite de puntos posibles
	public abstract boolean checkGameWinner(NGPlayerInfo p);
	
	// Para gestionar el final del juego según las decisiones de los clientes, ya sea porque desean volver a jugar o porque se salen 
	public abstract void controlEndGame(NGPlayerInfo p); 	
	
}
