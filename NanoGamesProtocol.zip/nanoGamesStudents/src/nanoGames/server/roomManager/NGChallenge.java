package nanoGames.server.roomManager;

public class NGChallenge {
	public short challengeAnswer;
	public String challenge;
	
	//Status initialization
	public NGChallenge() {
		challengeAnswer = 0;
		challenge = null;
	}

	public NGChallenge(short currentChallengeAnswer, String currentChallenge) {
		this.challengeAnswer = currentChallengeAnswer;
		challenge = currentChallenge;
	}

	public short getChallengeAnswer() {
		return challengeAnswer; // respuesta de la pregunta
	}

	public String getChallenge() {
		return challenge;
	}
	
	
	

}
