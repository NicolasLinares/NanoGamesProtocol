package nanoGames.server.roomManager;

public class NGRoomStatus {
	public short statusNumber;
	public String status;
	
	
	// Posibles estados de la room
	public short S_WAITING = 0;
	public short S_START_GAME = 1;
	public short S_CHECK_ROUND_WINNER = 2;
	public short S_END_GAME = 3;
	public short S_NOTIFY_EXIT = 4;
	public short S_SKIP_STATUS = 5;
	
	//Status initialization
	public NGRoomStatus() {
		statusNumber = 0;
		status = null;
	}

	public NGRoomStatus(short currentStatus, String message) {
		statusNumber = currentStatus;
		this.status = message;
	}

}
