package nanoGames.server;

public class NGPlayerInfo {
	
	public String nick; // Nickname of the user
	public short status; // Current status of the user (according to the automata)
	public int score;  // Current score of the user
	
	// AÑADIDAS
	public boolean turn; // Variable utilizada para gestionar los turnos de los jugadores, variable a true quiere decir que es mi turno
	public int lastAnswer; //número que corresponde a una respuesta, por ejemplo: (1)Rock   (2)Paper   (3)Scissors   (4)Lizard   (5)Spock
	
	//Constructor to make copies
	public NGPlayerInfo(NGPlayerInfo p) {
		this.nick = new String(p.nick);
		this.status = p.status;
		this.score = p.score;
		this.turn = false; // "no es mi turno", inicializamos sin turnos, se modifica al entrar a la room
	}
	
	//Default constructor
	public NGPlayerInfo(String nick) {
		this.nick = nick;
		this.score = 0;
		this.status = 0;
		this.turn = false; 
	}
	
	

}
